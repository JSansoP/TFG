import os
import sys
if __name__ == "__main__":
    print(os.path.exists(sys.argv[1]))